# ADAS - VS Code Execution Project

This folder contains the six programs from the uploaded ADAS notebook, modified from Google Colab to run locally in VS Code.

## Programs
1. MobileNetV2 image classification + ambient brightness/headlight decision
2. YOLO parking/object detection
3. Vehicle distance + Time To Collision (TTC) from video
4. Histogram equalization
5. SSD MobileNet vehicle detection
6. HSV-based traffic sign detection

## Folder structure
- `program1.py` ... `program6.py`
- `inputs/` - generated input images and test video
- `models/` - SSD MobileNet model files will be downloaded here
- `outputs/` - generated result images/video
- `download_models.py`
- `run_all.py`
- `requirements.txt`

## VS Code setup
Open this folder in VS Code, then in the Terminal run:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python download_models.py
```

Then run individually:

```bash
python program1.py
python program2.py
python program3.py
python program4.py
python program5.py
python program6.py
```

Or run all six:

```bash
python run_all.py
```

## Important
- The first run of TensorFlow MobileNetV2 downloads ImageNet weights.
- The first run of YOLO downloads `yolov8n.pt`.
- Program 5 needs the two SSD MobileNet model files; `download_models.py` downloads them.
- Internet is required for these model downloads.
- OpenCV programs display windows. Press a key to close Programs 2 and 6; press `q` to stop Program 3.
- The input images/video are generated for this project so you do not need the original Colab `/content/...` files.

The original notebook contains six main application programs, with additional installation/download cells. The local versions remove Colab-only commands such as `!pip`, `files.upload()`, `files.download()`, `/content/...`, and `cv2_imshow()`.
