from pathlib import Path
import urllib.request

OUT = Path(__file__).resolve().parent / 'models'
OUT.mkdir(exist_ok=True)
FILES = {'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt': 'https://raw.githubusercontent.com/zafarRehan/object_detection_COCO/main/ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt', 'frozen_inference_graph.pb': 'https://github.com/zafarRehan/object_detection_COCO/raw/main/frozen_inference_graph.pb'}

for name, url in FILES.items():
    target = OUT / name
    if target.exists() and target.stat().st_size > 1000:
        print(f'Already exists: {name}')
        continue
    print(f'Downloading {name}...')
    urllib.request.urlretrieve(url, target)
    print(f'Saved: {target}')