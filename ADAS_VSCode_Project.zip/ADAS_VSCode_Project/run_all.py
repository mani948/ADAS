# Run all six programs one by one.
# Programs 2, 3 and 6 open an OpenCV window; press a key when requested.
import subprocess, sys
from pathlib import Path

base = Path(__file__).resolve().parent
for i in range(1,7):
    print("\n" + "="*60)
    print(f"RUNNING PROGRAM {i}")
    print("="*60)
    result = subprocess.run([sys.executable, str(base/f"program{i}.py")])
    if result.returncode != 0:
        print(f"Program {i} stopped with exit code {result.returncode}.")
        break
print("\nFinished.")
